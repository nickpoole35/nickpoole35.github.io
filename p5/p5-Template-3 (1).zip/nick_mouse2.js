function setup() {
  var firstCanvas = createCanvas(600, 600);
}
function draw() {
}

function mouseMoved() {
   fill(random(200), random(200), random(200));
  line(mouseX, mouseY,10,10);
  rect(mouseX,mouseY,10,10);
}

function mouseClicked() {
  fill(random(200), random(200), random(200));
  ellipse(mouseX,mouseY,15);
}