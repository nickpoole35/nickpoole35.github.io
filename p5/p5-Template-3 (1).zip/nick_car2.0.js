function setup() {
  createCanvas(800, 600);
  background(70);
  }

function draw() {
  //drawCar(100,100,50,200);
  //drawCar(200,200,75,100);
  //drawcarLine(width/2, height/2,3,"l");
  drawTraffic();
}

function drawCar(carX, carY, carHeight, carTop) {
    //exhasut
    fill(50)
    rect(carX+100,carY+15,15,5);
    ellipse(carX+120,carY+5,7.5);
    ellipse(carX+130,carY-5,7.5);
   //car body
   //CarX originally 150
   //CarY originally 275
    fill(300,100,100)
    rect(carX+20,carY-25,62.5,25);
    fill(300,100,100)
    rect(carX,carY,100,25);
    //Wheels
    fill(0,0,0)
    ellipse(carX+20,carY+25,25,25);
    fill(0,0,0)
    ellipse(carX+82,carY+25,25,25);
    //windows
    fill(500)
    rect(carX+25,carY-15,20,10);

    //lines on the road(lanes top to bottom)
    fill(255,200,0);
    rect(-1,82,800,10);
    rect(-1,157,800,10);
    rect(-1,235,800,10);
}

function drawCarLine(carLineX, carLineY,numberCars,carDirection){
    count = 1;
    carHeight = 30;
    carTop = 102;
    while (count <= numberCars) {
      drawCar(carLineX,carLineY,carHeight, carTop);
      count = count + 1;
      if (carDirection == "r"){
        carLineX = (carLineX + 140);
        carTop = carTop + 50
      } else {
        carLineX = (carLineX - 10);
        carTop = carTop - 10
      }
      carHeight = 25+carHeight;
    }
}

function drawTraffic() {
  drawCarLine(width/8,height/3.1,4,"r");
  drawCarLine(width/8,height/2.2,2,"r");
  drawCarLine(width/8,height/13.5,3,"r");
  drawCarLine(width/8,height/5,1,"r");
}