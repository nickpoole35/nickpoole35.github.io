 //exhasut
    fill(50)
    rect(carX+100,carY+15,15,5);
    ellipse(carX+120,carY+5,7.5);
    ellipse(carX+130,carY-5,7.5);
   //car body
   //CarX originally 150
   //CarY originally 275
    fill(300,100,100)
    rect(carX+20,carY+100,62.5,25);
    fill(300,100,100)
    rect(carX,carY,100,25);
    //Wheels
    fill(0,0,0)
    ellipse(carX+20,carY+150,25,25);
    fill(0,0,0)
    ellipse(carX+82,carY+150,25,25);
    //windows
    fill(500)
    rect(carX+100,260,20,10);
    fill(500)
    rect(carX+25,260,20,10);
}

 //exhasut
    fill(50)
    rect(carX+100,290,15,5);
    ellipse(carX+120,280,7.5);
    ellipse(carX+130,270,7.5);
   //car body
   //CarX originally 150
   //CarY originally 275
    fill(300,100,100)
    rect(carX+20,250,62.5,25);
    fill(300,100,100)
    rect(carX,275,100,25);
    //Wheels
    fill(0,0,0)
    ellipse(carX+20,300,25,25);
    fill(0,0,0)
    ellipse(carX+82,300,25,25);
    //windows
    fill(500)
    rect(carX+100,260,20,10);
    fill(500)
    rect(carX+25,260,20,10);
}
