 //position variables
 var posX= 150;
 var posY = 150;
 // speed variables
 var speedX = 0;
 var speedy = 0;

function setup() {
  createCanvas(800, 600);
  background(150,100,20)
  frameRate(30);
}
  
function draw () {
 background(150,0,200);
 fill(10,400,150)
 rect(posX, posY, 20, 20); // square
 posX = posX + speedX;

 if (posX > width || posX < 0) {
   speedX = -speedX
 }
 
}

  function mouseClicked() {
   // put the position x of the object where the mouse is
posX = mouseX;
posY = mouseY
  // put the position of y of the object where the mouse is posy = mousey;
 speedX = round(mouseX/50)
  }