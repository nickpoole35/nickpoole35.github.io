function setup() {
  createCanvas(800, 500);
  
  //set up p1 initial position
  p1x =50
  p1y =275

  //set up p2 initial position
  p2x =465
  p2y =275
}
  function draw() {
 background(0)

  //finish
  fill(300,50,50);
  rect(180,50,150,15);

  //left flag
  fill(20,20,300);
  rect(200,27,25,8);
  fill(400);
  rect(225,28,5,25);
  //right flag
  fill(20,20,300);
  rect(285,27,25,8);
  fill(400);
  rect(280,28,5,25);

  //border
  fill(90);
  rect(250,-5,10,350);

  //first jump on left
  fill(300,50,50);
  rect(150,250,100,15);
  //second jump on left
  fill(300,50,50);
  rect(-1,200,200,15);
  //third jump on the left
  fill(300,50,50);
  rect(50,150,100,15);
  //foruth jump on the left
  fill(300,50,50);
  rect(125,100,50,15);

  //first jump on the right
  fill(300,50,50);
  rect(350,250,100,15);
  //second jump on the right
  fill(300,50,50);
  rect(300,200,100,15);
  //third jump on the right
  fill(300,50,50);
  rect(375,150,25,15);
  //foruth jump on the right
  fill(300,50,50);
  rect(440,150,50,15);
  //fifth jump on the right
  fill(300,50,50);
  rect(325,100,100,15);
  fill(200,150,50);
  //ground
  rect(-5,300,800,100);

  //p1
  fill(0,200,50);
  rect(p1x,p1y,25,25);

  //p2
  fill(0,200,50);
  rect(p2x,p2y,25,25);
  
    //move p1 based on the input from the (ARROW KEYS)
  if (keyIsDown(RIGHT_ARROW)) {
    p1x+=5;
  }
  if (keyIsDown(LEFT_ARROW)) {
    p1x-=5;
  }
  if (keyIsDown(UP_ARROW)) {
    p1y-=5;
  }
  if (keyIsDown(DOWN_ARROW)) {
    p1y+=5;
  }

   //move p2 based on the input from the (KEYS D,A,W,S)
  if (keyIsDown(68)) {
    p2x+=5;
  }
  if (keyIsDown(65)) {
    p2x-=5;
  }
  if (keyIsDown(87)) {
    p2y-=5;
  }
  if (keyIsDown(83)) {
    p2y+=5;
  }

}