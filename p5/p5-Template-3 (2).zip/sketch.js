function setup() {
  				createCanvas(640, 480);
			}

			function draw() {
  				ellipse(200, 200, 80, 80);
			}