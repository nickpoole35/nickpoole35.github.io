/* Mouse following using automatic function calls.
Courtney Edwards 2018-09-01*/

function setup() {
  var firstCanvas = createCanvas(600, 600);
}

function draw() {
}

function mouseMoved() {
  rect(mouseX, mouseY, 15, 15);
}

function mouseClicked() {
  fill(random(200), random(200), random(200));
  ellipse(mouseX,mouseY,15);
}